//go:build !windows

package brokenfs

const (
	Root = "/"
)
