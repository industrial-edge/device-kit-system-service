// Code generated via scripts/generate.sh. DO NOT EDIT.

//go:build !windows

package must

var (
	fsRoot = "/"
)
