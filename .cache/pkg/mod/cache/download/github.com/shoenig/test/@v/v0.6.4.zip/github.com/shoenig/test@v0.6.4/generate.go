package test

// Generate must package.

//go:generate ./scripts/generate.sh
